import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Founder from "./components/Founder";
import Values from "./components/Values";
import ContactCTA from "./components/ContactCTA";
import Footer from "./components/Footer";

import blueGem from "./assets/blue-gem.png";
import pinkGem from "./assets/pink-gem.png";
import greenGem from "./assets/green-gem.png";
import goldGem from "./assets/gold-gem.png";

function GemShowcase() {
  const gemstones = [
    {
      id: "01",
      name: "Blue Sapphire",
      image: blueGem,
    },
    {
      id: "02",
      name: "Ruby",
      image: pinkGem,
    },
    {
      id: "03",
      name: "Emerald",
      image: greenGem,
    },
    {
      id: "04",
      name: "Golden Sapphire",
      image: goldGem,
    },
  ];

  return (
    <section className="gem-showcase section" id="gemstones">
      <div className="gem-showcase-glow gem-showcase-glow-left" />
      <div className="gem-showcase-glow gem-showcase-glow-right" />

      <div className="container gem-showcase-container">
        <div className="gem-showcase-header">
          <div className="gem-showcase-heading">
            <p className="gem-showcase-label">
              <span />
              Our Gemstones
            </p>

            <h2>
              Nature’s Finest
              <br />
              <em>Masterpieces</em>
            </h2>
          </div>

          <div className="gemstone-grid">
            {gemstones.map((gemstone) => (
              <article className="gemstone-card" key={gemstone.id}>
                <div className="gemstone-image-wrapper">
                  <img
                    src={gemstone.image}
                    alt={gemstone.name}
                    className="gemstone-image"
                  />
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Founder />
        <Values />
        <GemShowcase />
        <ContactCTA />
      </main>
      <Footer />
    </>
  );
}

export default App;