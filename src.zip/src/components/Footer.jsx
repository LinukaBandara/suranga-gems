import { Gem, MapPin } from "lucide-react";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaWhatsapp,
} from "react-icons/fa";

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="brand">
            <Gem className="brand-diamond" strokeWidth={1.2} />
            <div className="brand-text">
              <span className="brand-main">SURANGA</span>
              <span className="brand-sub">GEMS</span>
              <span className="brand-country">MADAGASCAR · SRI LANKA</span>
            </div>
          </div>

          <p>
            Sourcing Madagascar and Sri Lanka gemstones with refined service,
            global reach and absolute discretion.
          </p>
        </div>

        <div className="footer-column">
          <h3>Quick Links</h3>
          <a href="/">Home</a>
          <a href="/#about">Our Founder</a>
          <a href="/#values">Why Us</a>
          <a href="/contact">Contact</a>
        </div>

        <div className="footer-column">
          <h3>Our Presence</h3>

          <p className="footer-location">
            <MapPin size={16} />
            <span>Ilakaka, Madagascar</span>
          </p>

          <p className="footer-location">
            <MapPin size={16} />
            <span>Colombo, Sri Lanka</span>
          </p>

          <p className="footer-location">
            <MapPin size={16} />
            <span>Balangoda, Sri Lanka</span>
          </p>
        </div>

        <div className="footer-social-group">
          <div className="footer-social-label">Connect</div>
          <div className="social-links">
            <a
              href="https://wa.me/94000000000"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
            >
              <FaWhatsapp />
            </a>
            <a href="#contact" aria-label="Contact via Facebook">
              <FaFacebookF />
            </a>
            <a href="#contact" aria-label="Contact via Instagram">
              <FaInstagram />
            </a>
            <a href="#contact" aria-label="Contact via LinkedIn">
              <FaLinkedinIn />
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        © 2026 Suranga Gems. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;
