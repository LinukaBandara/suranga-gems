import { useState } from "react";
import { ArrowRight, Mail, MessageCircle, Phone } from "lucide-react";

function ContactCTA() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!name.trim() || !email.trim() || !message.trim()) {
      setStatus("Please complete all fields before sending your inquiry.");
      return;
    }

    const mailTo = `mailto:info@surangagems.com?subject=${encodeURIComponent(
      "Suranga Gems Inquiry"
    )}&body=${encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`
    )}`;

    setStatus("Opening your email client...");
    window.location.href = mailTo;
  };

  return (
    <section className="contact-cta">
      <div className="container contact-cta-container">
        <div className="contact-copy">
          <p className="section-label">Contact</p>
          <h1>Private introductions, rare sourcing and discreet support.</h1>
          <p className="contact-intro">
            For gemstone sourcing, partnership inquiries or bespoke consultations,
            connect with Suranga Gems and experience a service designed for
            collectors and trusted industry partners.
          </p>

          <div className="contact-actions">
            <a
              href="https://wa.me/94000000000"
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle size={20} />
              <span>WhatsApp</span>
              <ArrowRight size={18} />
            </a>

            <a href="tel:+94000000000">
              <Phone size={20} />
              <span>Call Us</span>
              <ArrowRight size={18} />
            </a>

            <a href="mailto:info@surangagems.com">
              <Mail size={20} />
              <span>Email Us</span>
              <ArrowRight size={18} />
            </a>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit}>
          <label htmlFor="contact-name">Name</label>
          <input
            id="contact-name"
            type="text"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Your name"
            required
          />

          <label htmlFor="contact-email">Email</label>
          <input
            id="contact-email"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="you@example.com"
            required
          />

          <label htmlFor="contact-message">Message</label>
          <textarea
            id="contact-message"
            rows="6"
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            placeholder="Tell us about your gemstone needs, collection, or partnership inquiry."
            required
          />

          <button type="submit" className="contact-submit">
            Send Message
          </button>

          {status && <p className="contact-status">{status}</p>}
        </form>
      </div>
    </section>
  );
}

export default ContactCTA;
