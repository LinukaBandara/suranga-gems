import { Gem, Menu, X } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import { useState } from "react";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="navbar">
      <div className="container navbar-container">
        <a href="#home" className="brand" onClick={closeMenu}>
          <Gem className="brand-diamond" strokeWidth={1.25} />
          <div className="brand-text">
            <span className="brand-main">SURANGA</span>
            <span className="brand-sub">GEMS</span>
            <span className="brand-country">MADAGASCAR · SRI LANKA</span>
          </div>
        </a>

        <nav
          id="primary-navigation"
          className={`nav-menu ${menuOpen ? "nav-menu-open" : ""}`}
          aria-label="Main navigation"
        >
          <a href="/" onClick={closeMenu}>Home</a>
          <a href="/#about" onClick={closeMenu}>Our Founder</a>
          <a href="/#values" onClick={closeMenu}>Why Us</a>
          <a href="/contact" onClick={closeMenu}>Contact Us</a>
        </nav>

        <a
          href="https://wa.me/94000000000"
          target="_blank"
          rel="noopener noreferrer"
          className="navbar-whatsapp"
        >
          <FaWhatsapp />
          <span>WhatsApp</span>
        </a>

        <button
          type="button"
          className="mobile-menu-button"
          aria-controls="primary-navigation"
          aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={27} /> : <Menu size={27} />}
        </button>
      </div>
    </header>
  );
}

export default Navbar;
